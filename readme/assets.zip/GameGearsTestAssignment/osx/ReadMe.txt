Если пишет "Не удается открыть программу «TestAssignmentMacOs»."
sudo chmod -R 755 /путь к файлу/TestAssignmentMacOs.app